const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ChannelSelectMenuBuilder,
    ChannelType
} = require('discord.js');
const { getGuildConfig, saveGuildConfig } = require('../utils/jsonDb');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Setup bot configurations')
        .addSubcommand(subcommand =>
            subcommand
                .setName('welcome')
                .setDescription('Configure the welcome message system')),

    async execute(interaction) {
        if (interaction.options.getSubcommand() === 'welcome') {
            await this.showDashboard(interaction);
        }
    },

    async showDashboard(interaction, update = false) {
        const guildId = interaction.guildId;
        let config = getGuildConfig(guildId);

        const embed = new EmbedBuilder()
            .setTitle('Welcome System Setup')
            .setDescription('Configure how new members are welcomed.')
            .addFields(
                { name: 'Channel', value: config.channelId ? `<#${config.channelId}>` : 'Not Set', inline: true },
                { name: 'Log Channel', value: config.logChannelId ? `<#${config.logChannelId}>` : 'Not Set', inline: true },
                { name: 'Status', value: config.channelId ? '🟢 Active' : '🔴 Inactive (Set Channel)', inline: true },
                { name: 'Embed Settings', value: `**Title:** ${config.embed.title || 'None'}\n**Color:** ${config.embed.color}` },
                { name: 'Options', value: `Mention User: ${config.options.mentionUser ? '✅' : '❌'}\nUser Avatar in Thumb: ${config.options.useUserAvatarInThumbnail ? '✅' : '❌'}` }
            )
            .setColor(config.embed.color || '#00FF00');

        const row1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('setup_btn_channels').setLabel('Channels').setStyle(ButtonStyle.Primary).setEmoji('📢'),
            new ButtonBuilder().setCustomId('setup_btn_embed').setLabel('Embed Content').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('setup_btn_images').setLabel('Images').setStyle(ButtonStyle.Secondary).setEmoji('🖼️'),
            new ButtonBuilder().setCustomId('setup_btn_options').setLabel('Options').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
        );

        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('setup_btn_preview').setLabel('Test / Preview').setStyle(ButtonStyle.Success).setEmoji('▶️')
        );

        const payload = { embeds: [embed], components: [row1, row2], ephemeral: true };

        if (update) {
            await interaction.update(payload);
        } else {
            await interaction.reply(payload);
        }
    },

    async handleInteraction(interaction) {
        const guildId = interaction.guildId;
        let config = getGuildConfig(guildId);
        let shouldSave = false;

        // --- BUTTONS ---
        if (interaction.customId === 'setup_btn_channels') {
            const row1 = new ActionRowBuilder().addComponents(
                new ChannelSelectMenuBuilder()
                    .setCustomId('setup_select_welcome_channel')
                    .setPlaceholder('Select Welcome Channel')
                    .setChannelTypes(ChannelType.GuildText)
            );
            const row2 = new ActionRowBuilder().addComponents(
                new ChannelSelectMenuBuilder()
                    .setCustomId('setup_select_log_channel')
                    .setPlaceholder('Select Log Channel')
                    .setChannelTypes(ChannelType.GuildText)
            );
            const row3 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('setup_btn_back').setLabel('Back').setStyle(ButtonStyle.Secondary)
            );
            await interaction.update({ content: 'Select Channels:', embeds: [], components: [row1, row2, row3] });
        }
        else if (interaction.customId === 'setup_btn_embed') {
            const modal = new ModalBuilder().setCustomId('setup_modal_embed').setTitle('Edit Embed Content');

            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('Title').setStyle(TextInputStyle.Short).setRequired(false).setValue(config.embed.title || '')),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Description').setStyle(TextInputStyle.Paragraph).setRequired(true).setValue(config.embed.description || 'Welcome {user} to {server}!')),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('footerText').setLabel('Footer Text').setStyle(TextInputStyle.Short).setRequired(false).setValue(config.embed.footerText || '')),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('Color (Hex)').setStyle(TextInputStyle.Short).setRequired(false).setValue(config.embed.color || '#00FF00'))
            );
            await interaction.showModal(modal);
        }
        else if (interaction.customId === 'setup_btn_images') {
            const modal = new ModalBuilder().setCustomId('setup_modal_images').setTitle('Edit Embed Images');
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('image').setLabel('Main Image URL').setStyle(TextInputStyle.Short).setRequired(false).setValue(config.embed.image || '')),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('thumbnail').setLabel('Thumbnail URL').setStyle(TextInputStyle.Short).setRequired(false).setValue(config.embed.thumbnail || '')),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('footerImage').setLabel('Footer Icon URL').setStyle(TextInputStyle.Short).setRequired(false).setValue(config.embed.footerImage || ''))
            );
            await interaction.showModal(modal);
        }
        else if (interaction.customId === 'setup_btn_options') {
            // Options Menu
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('setup_toggle_mention').setLabel(`Mention User: ${config.options.mentionUser ? 'ON' : 'OFF'}`).setStyle(config.options.mentionUser ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('setup_toggle_authumb').setLabel(`User Avatar Thumb: ${config.options.useUserAvatarInThumbnail ? 'ON' : 'OFF'}`).setStyle(config.options.useUserAvatarInThumbnail ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('setup_btn_back').setLabel('Back').setStyle(ButtonStyle.Secondary)
            );
            await interaction.update({ content: 'Toggle Options:', embeds: [], components: [row] });
        }
        else if (interaction.customId === 'setup_toggle_mention') {
            config.options.mentionUser = !config.options.mentionUser;
            shouldSave = true;
            // Re-render
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('setup_toggle_mention').setLabel(`Mention User: ${config.options.mentionUser ? 'ON' : 'OFF'}`).setStyle(config.options.mentionUser ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('setup_toggle_authumb').setLabel(`User Avatar Thumb: ${config.options.useUserAvatarInThumbnail ? 'ON' : 'OFF'}`).setStyle(config.options.useUserAvatarInThumbnail ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('setup_btn_back').setLabel('Back').setStyle(ButtonStyle.Secondary)
            );
            await interaction.update({ components: [row] });
        }
        else if (interaction.customId === 'setup_toggle_authumb') {
            config.options.useUserAvatarInThumbnail = !config.options.useUserAvatarInThumbnail;
            shouldSave = true;
            // Re-render
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('setup_toggle_mention').setLabel(`Mention User: ${config.options.mentionUser ? 'ON' : 'OFF'}`).setStyle(config.options.mentionUser ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('setup_toggle_authumb').setLabel(`User Avatar Thumb: ${config.options.useUserAvatarInThumbnail ? 'ON' : 'OFF'}`).setStyle(config.options.useUserAvatarInThumbnail ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('setup_btn_back').setLabel('Back').setStyle(ButtonStyle.Secondary)
            );
            await interaction.update({ components: [row] });
        }
        else if (interaction.customId === 'setup_btn_back') {
            await this.showDashboard(interaction, true);
        }
        else if (interaction.customId === 'setup_btn_preview') {
            // Generate a fake welcome message
            await interaction.deferReply({ ephemeral: true });
            const member = interaction.member;

            let description = config.embed.description
                .replace(/{user}/g, member.toString())
                .replace(/{server}/g, interaction.guild.name)
                .replace(/{memberCount}/g, interaction.guild.memberCount);

            const embed = new EmbedBuilder()
                .setDescription(description)
                .setColor(config.embed.color);

            if (config.embed.title) embed.setTitle(config.embed.title);
            if (config.embed.image) embed.setImage(config.embed.image);

            if (config.options.useUserAvatarInThumbnail) {
                embed.setThumbnail(member.user.displayAvatarURL({ dynamic: true }));
            } else if (config.embed.thumbnail) {
                embed.setThumbnail(config.embed.thumbnail);
            }

            if (config.embed.footerText) {
                embed.setFooter({ text: config.embed.footerText, iconURL: config.embed.footerImage });
            }

            let content = config.options.mentionUser ? `${member}` : undefined;

            await interaction.editReply({ content: content, embeds: [embed] });
        }

        // --- SELECTS ---
        else if (interaction.customId === 'setup_select_welcome_channel') {
            config.channelId = interaction.values[0];
            shouldSave = true;
            await interaction.deferUpdate();
        }
        else if (interaction.customId === 'setup_select_log_channel') {
            config.logChannelId = interaction.values[0];
            shouldSave = true;
            await interaction.deferUpdate();
        }

        // --- MODALS ---
        else if (interaction.isModalSubmit()) {
            if (interaction.customId === 'setup_modal_embed') {
                config.embed.title = interaction.fields.getTextInputValue('title');
                config.embed.description = interaction.fields.getTextInputValue('description');
                config.embed.footerText = interaction.fields.getTextInputValue('footerText');
                config.embed.color = interaction.fields.getTextInputValue('color');
                shouldSave = true;
                // Just update the dashboard directly, which calls update()
                await this.showDashboard(interaction, true);
            }
            else if (interaction.customId === 'setup_modal_images') {
                config.embed.image = interaction.fields.getTextInputValue('image');
                config.embed.thumbnail = interaction.fields.getTextInputValue('thumbnail');
                config.embed.footerImage = interaction.fields.getTextInputValue('footerImage');
                shouldSave = true;
                await this.showDashboard(interaction, true);
            }
        }

        if (shouldSave) {
            saveGuildConfig(guildId, config);
        }
    }
};
